# Muhammad Bilal — Portfolio (Next.js, webpack)
`npm install && npm run dev` (uses `next dev --webpack`, so it works on Termux/Android). Build with `npm run build`.
Edit: `components/Sections.tsx` (hero, projects, contact), `Journey.tsx` (the S array), `Word.tsx`, `skills.engine.ts` (SK), `services.engine.ts` (D).
