"use client";
import { useEffect, useRef } from "react";
import "./services.css";
import init from "./services.engine";
const HTML = "<section class=\"services\" id=\"services\" aria-labelledby=\"sv-h\">\n  <div class=\"bg\" aria-hidden=\"true\"><div class=\"disc d1\"></div><div class=\"disc d2\"></div></div>\n  <header class=\"head\">\n    <span class=\"lab\">Services</span>\n    <h2 id=\"sv-h\">What I can build for you</h2>\n    <p>Six ways I can help turn an idea into something that ships, from the first sketch to the support after launch. Hover a card to hold it still and read what it covers.</p>\n  </header>\n  <div class=\"rails\"></div>\n  <p class=\"note\">Hover to steady and flip \u00b7 tap on touch screens</p>\n  <ol class=\"flow\" aria-label=\"How we work\"><li><span>1</span>Discover</li><li><span>2</span>Design</li><li><span>3</span>Build</li><li><span>4</span>Launch</li><li><span>5</span>Support</li></ol>\n</section>";
export default function Services() {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => init(ref.current as HTMLElement), []);
  return <section ref={ref} id="services" className="w-services" dangerouslySetInnerHTML={{ __html: HTML }} />;
}
