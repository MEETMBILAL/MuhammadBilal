// @ts-nocheck
"use client";
import { useEffect, useRef, useState } from "react";

const S = [
  ["Course", "The first three months", "A structured course gave me the foundations: HTML, CSS, JavaScript and how the web fits together.", "#4B9BE0"],
  ["React", "Learning React", "Components, hooks and state. This is where building interfaces started to click.", "#00a3ba"],
  ["Python", "Picking up Python", "Scripting and backend logic with Python, and my first steps into Django.", "#b04ddb"],
  ["Websites", "Personal websites", "I shipped my own sites to practise responsive design, SEO and deployment.", "#4B9BE0"],
  ["After Concept", "Joined After Concept", "Three months of internship training alongside senior developers.", "#00a3ba"],
  ["Client work", "Projects for clients and companies", "Dashboards, landing pages and an AI estimation SaaS, built for real users and shipped to production.", "#b04ddb"],
  ["Full Stack Engineer", "The top of the stairs", "React and Next.js in front, Python and Django behind. One developer from database to interface.", "var(--ink)"],
];
const H = 84, D = 230, E = 190, Z0 = 260, N = S.length - 1;

export default function Journey() {
  const sec = useRef(null), world = useRef(null), bar = useRef(null), view = useRef(null);
  const [i, setI] = useState(0);
  const go = (k) => {
    const r = sec.current.getBoundingClientRect();
    scrollTo({ top: scrollY + r.top + (Math.max(0, Math.min(N, k)) / N) * (r.height - innerHeight), behavior: "smooth" });
  };
  useEffect(() => {
    const rm = matchMedia("(prefers-reduced-motion: reduce)").matches;
    let cur = 0, tgt = 0, last = -1, raf = 0, vis = false;
    const read = () => {
      const r = sec.current.getBoundingClientRect();
      vis = r.bottom > 0 && r.top < innerHeight;
      tgt = Math.min(1, Math.max(0, -r.top / (r.height - innerHeight))) * N;
    };
    const loop = () => {
      if (vis || cur !== tgt) {
        cur += rm ? tgt - cur : (tgt - cur) * 0.12;
        if (Math.abs(tgt - cur) < 0.002) cur = tgt;
        world.current.style.transform = `translate3d(0,${cur * H}px,${cur * D}px)`;
        bar.current.style.transform = `scaleX(${cur / N})`;
        const k = Math.round(cur);
        if (k !== last) { last = k; setI(k); }
      }
      raf = requestAnimationFrame(loop);
    };
    const mv = (e) => { if (vis && !rm) view.current.style.perspectiveOrigin = `${50 + (e.clientX / innerWidth - 0.5) * 10}% ${35 + (e.clientY / innerHeight - 0.5) * 6}%`; };
    const key = (e) => { if (!vis) return; if (e.key === "ArrowRight") go(Math.round(cur) + 1); if (e.key === "ArrowLeft") go(Math.round(cur) - 1); };
    read();
    addEventListener("scroll", read, { passive: true }); addEventListener("resize", read); addEventListener("pointermove", mv); addEventListener("keydown", key);
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); removeEventListener("scroll", read); removeEventListener("resize", read); removeEventListener("pointermove", mv); removeEventListener("keydown", key); };
  }, []);

  return (
    <section ref={sec} className="j-sec" id="journey" aria-label="My journey">
      <div className="j-stage">
        <div className="j-view" ref={view}>
          <div className="j-world" ref={world}>
            {S.map((s, k) => k >= i - 2 && (
              <div key={k} className={"j-step" + (k === i ? " on" : "")} style={{ transform: `translate3d(0,${E - k * H}px,${-Z0 - k * D}px)`, "--c": s[3] }}>
                <button className="j-riser" onClick={() => go(k)} aria-label={`Go to step ${k + 1}: ${s[1]}`}><b>{s[0]}</b><span>{String(k + 1).padStart(2, "0")}</span></button>
                <i className="j-tread" style={{ height: D }} />
              </div>
            ))}
          </div>
        </div>
        <div className="j-ui">
          <div><p className="eyebrow">Journey</p><h2>My journey, one step at a time</h2><p>Scroll, tap a step or use the arrows to climb.</p></div>
          <div className="j-info" key={i}>
            <span>Step {String(i + 1).padStart(2, "0")} of {String(S.length).padStart(2, "0")}</span>
            <h3>{S[i][1]}</h3>
            <p>{S[i][2]}</p>
            <div className="j-row">
              <button onClick={() => go(i - 1)} disabled={i === 0} aria-label="Previous step">‹</button>
              <div className="j-prog"><i ref={bar} /></div>
              <button onClick={() => go(i + 1)} disabled={i === N} aria-label="Next step">›</button>
            </div>
          </div>
        </div>
        <div className="j-dots">{S.map((s, k) => <button key={k} className={k === i ? "on" : ""} onClick={() => go(k)} aria-label={`Step ${k + 1}: ${s[0]}`} />)}</div>
      </div>
    </section>
  );
}
