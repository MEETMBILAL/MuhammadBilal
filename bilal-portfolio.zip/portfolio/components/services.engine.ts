// @ts-nocheck
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);
export default function init(root) {
  const __c = []; let __dead = false, __raf = 0;
  const __tk = (f) => { gsap.ticker.add(f); __c.push(() => gsap.ticker.remove(f)); };
  const __ae = (...a) => { window.addEventListener(...a); __c.push(() => window.removeEventListener(...a)); };
  const RO = function (cb) { const o = new ResizeObserver(cb); __c.push(() => o.disconnect()); return o; };
  const ctx = gsap.context(() => {

const D=[
{n:"Web Development",d:"Fast, responsive websites and web apps, built from clean code that is easy to maintain and grow.",l:["Responsive layouts for every screen","Accessible, semantic markup","Performance and SEO basics built in","Clean handover and documentation"],t:["React","Next.js","Tailwind CSS"]},
{n:"UI / UX Design",d:"Clear, considered interfaces shaped around how people actually use your product.",l:["User flows and wireframes","Interactive prototypes","Visual design and components","Hand-off that is ready to build"],t:["Wireframes","Prototypes","Design systems"]},
{n:"Frontend Engineering",d:"Component-driven interfaces with React and TypeScript, finished with smooth, purposeful motion.",l:["Reusable component libraries","Typed, predictable code","Data fetching and state, done right","Polished animation and interaction"],t:["React","TypeScript","Animation"]},
{n:"Backend & APIs",d:"Reliable server logic, data models and APIs built with Python and Django.",l:["Database design and migrations","Clean REST API endpoints","Authentication and permissions","Secure, well-structured services"],t:["Python","Django","REST"]},
{n:"Full-Stack Apps",d:"End-to-end products from database to interface, delivered as one coherent piece.",l:["Frontend and backend in one hand","User accounts and dashboards","A deployment-ready setup","Version-controlled with Git"],t:["Next.js","Django","Git"]},
{n:"Maintenance & Support",d:"Ongoing fixes, updates and improvements once your product is live.",l:["Bug fixes and dependency updates","Small feature additions","Regular performance check-ups","Clear notes on every change"],t:["Updates","Bug fixes","Monitoring"]}
];
const rails=root.querySelector('.rails'),RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
rails.innerHTML=D.map((s,i)=>`<div class="slot"><i class="rail"></i><div class="hang"><i class="str"></i>
<div class="card" tabindex="0" role="button" aria-label="${s.n}. ${s.d}"><div class="in">
<div class="face front"><span class="num">0${i+1}</span><h3>${s.n}</h3><i></i></div>
<div class="face back"><h4>${s.n}</h4><p>${s.d}</p><b>What you get</b><ul>${s.l.map(x=>`<li>${x}</li>`).join('')}</ul><div class="tags">${s.t.map(x=>`<span>${x}</span>`).join('')}</div></div>
</div></div></div></div>`).join('');

/* touch + keyboard flip */
rails.addEventListener('pointerup',e=>{if(e.pointerType==='mouse')return;const c=e.target.closest('.card');if(c)c.classList.toggle('on')});
rails.addEventListener('keydown',e=>{if(e.key!=='Enter'&&e.key!==' ')return;const c=e.target.closest('.card');if(c){e.preventDefault();c.classList.toggle('on')}});

if(!RM){
  gsap.registerPlugin(ScrollTrigger);
  const hangs=[...rails.querySelectorAll('.hang')],canHover=matchMedia('(hover:hover)').matches;
  /* each pendulum: own amplitude, period and starting phase, so they never swing in step */
  const AMP=[4.6,3.8,5.2,4.2,4.9,4,],PER=[3.1,3.7,2.8,4,3.3,3.6],PH=[0,2.1,4.2,1,3.1,5.2];
  const P=hangs.map((h,i)=>({h,q:gsap.quickSetter(h,'rotation','deg'),A:AMP[i],w:Math.PI*2/PER[i],ph:PH[i],k:1,env:2.6,live:false,card:h.querySelector('.card')}));
  gsap.set(hangs,{autoAlpha:0,y:-70});gsap.set(root.querySelectorAll('.rail'),{scaleX:0});
  let vis=false;
  ScrollTrigger.create({trigger:root,start:'top bottom',end:'bottom top',onToggle:s=>vis=s.isActive});
  ScrollTrigger.create({trigger:rails,start:'top 80%',once:true,onEnter:()=>{
    gsap.to(root.querySelectorAll('.rail'),{scaleX:1,duration:.9,stagger:.06,ease:'power2.out'});
    P.forEach((o,i)=>{const dl=.3+i*.12;gsap.to(o.h,{y:0,autoAlpha:1,duration:.7,delay:dl,ease:'power3.out'});gsap.delayedCall(dl,()=>o.live=true)});
  }});
  /* simple harmonic motion: angle = A·sin(ωt+φ). The hovered, focused or flipped card eases its amplitude to zero and rests at centre. */
  __tk((t,dt)=>{
    if(!vis)return;const s=dt/1000;
    for(const o of P){
      if(!o.live)continue;
      const hold=(canHover&&o.h.matches(':hover'))||o.card.classList.contains('on')||o.card.matches(':focus-visible');
      o.k+=((hold?0:1)-o.k)*(1-Math.exp(-s*5));
      o.env+=(1-o.env)*(1-Math.exp(-s*.7));
      o.q(o.A*o.env*o.k*Math.sin(o.w*t+o.ph));
    }
  });
}

  });
  return () => { __dead = true; cancelAnimationFrame(__raf); __c.forEach((f) => f()); ctx.revert(); };
}
