import type { CSSProperties } from "react";
const dot = (c: string) => ({ "--dot": c }) as CSSProperties;
const stats = [["6+", "months shipping"], ["6", "client and company projects"], ["1", "live AI estimation SaaS"], ["4", "cities in one dashboard"]];
const stack = ["React", "Next.js", "TypeScript", "JavaScript", "Tailwind CSS", "Python", "Django", "Node.js", "REST APIs", "SQLite", "Git", "GitHub", "Figma", "Vercel"];
const cards = [["Email", "dmbilaldev@gmail.com", "mailto:dmbilaldev@gmail.com", "#b04ddb"], ["Phone", "+92 309 3146450", "tel:+923093146450", "#4B9BE0"], ["Location", "Bahawalpur, Pakistan", "", "#00a3ba"], ["Portfolio", "dmbilal.vercel.app", "https://dmbilal.vercel.app", "#6a57e3"]];

export function Hero() {
  return (
    <section className="c-hero">
      <i className="bloom b1" /><i className="bloom b2" />
      <div className="c-wrap">
        <p className="eyebrow">Full Stack Developer · Bahawalpur, Pakistan</p>
        <h1>I build products<br />that ship.</h1>
        <p className="c-sub">React and Next.js interfaces on top of Python and Django backends: SaaS platforms, analytics dashboards and client web apps. Six months of production experience, open to remote work worldwide.</p>
        <div className="c-cta">
          <a className="c-btn dark lg" href="#work">See my work</a>
          <a className="c-btn ghost lg" href="/Muhammad_Bilal_CV.pdf" download>Download CV</a>
        </div>
        <dl className="c-stats">{stats.map(([n, l]) => <div key={l}><dt>{n}</dt><dd>{l}</dd></div>)}</dl>
      </div>
      <div className="c-marq" aria-label="Technologies I work with"><div>{[...stack, ...stack].map((t, i) => <span key={i}>{t}</span>)}</div></div>
    </section>
  );
}

export function Contact() {
  return (
    <section className="c-contact" id="contact">
      <div className="c-wrap">
        <p className="eyebrow">Contact</p>
        <h2>Have a product to build? Let’s talk.</h2>
        <p>Tell me what you need and I’ll reply with a plan, a timeline and the first steps.</p>
        <div className="c-cta">
          <a className="c-btn dark" href="mailto:dmbilaldev@gmail.com">Email me</a>
          <a className="c-btn ghost" href="/Muhammad_Bilal_CV.pdf" download>Download CV</a>
        </div>
        <ul className="c-cards">
          {cards.map(([t, v, h, c]) => (
            <li key={t}>
              <span className="cx-chip"><i style={dot(c)} />{t}</span>
              {h ? <a href={h} target={h.startsWith("http") ? "_blank" : undefined} rel="noopener">{v}</a> : <b>{v}</b>}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="c-foot">
      <div className="c-wrap c-fgrid">
        <div><a className="c-sig" href="#top">Muhammad Bilal</a><p>Full Stack Developer building with React, Next.js, Python and Django. Open to remote work worldwide.</p></div>
        <nav aria-label="Explore"><b>Explore</b><a href="#work">Work</a><a href="#skills">Skills</a><a href="#services">Services</a><a href="#journey">Journey</a></nav>
        <nav aria-label="Connect"><b>Connect</b><a href="https://github.com/meetmbilal" target="_blank" rel="noopener">GitHub</a><a href="https://linkedin.com/in/meetmbilal" target="_blank" rel="noopener">LinkedIn</a><a href="https://dmbilal.vercel.app" target="_blank" rel="noopener">Portfolio</a><a href="/Muhammad_Bilal_CV.pdf" download>CV</a></nav>
      </div>
      <div className="c-wrap c-fbot"><span>© 2026 Muhammad Bilal. Built with Next.js.</span><a href="#top">Back to top</a></div>
    </footer>
  );
}
