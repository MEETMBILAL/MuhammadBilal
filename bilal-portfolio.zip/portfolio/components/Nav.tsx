"use client";
import { useState } from "react";
const L = [["Work", "#work"], ["Skills", "#skills"], ["Services", "#services"], ["Journey", "#journey"], ["Contact", "#contact"]];
export default function Nav() {
  const [o, setO] = useState(false);
  const close = () => setO(false);
  const flip = () => {
    const d = document.documentElement, t = d.dataset.theme === "dark" ? "light" : "dark";
    d.dataset.theme = t;
    try { localStorage.setItem("theme", t); } catch {}
  };
  return (
    <header className={"c-nav" + (o ? " open" : "")}>
      <div className="c-pillbar">
        <a className="c-logo" href="#top" onClick={close} aria-label="Muhammad Bilal, home">Muhammad Bilal</a>
        <nav className="c-links" aria-label="Primary">{L.slice(0, 4).map(([t, h]) => <a key={h} href={h}>{t}</a>)}</nav>
        <div className="c-side">
          <button className="c-theme" onClick={flip} aria-label="Toggle light and dark theme">
            <svg className="sun" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></svg>
            <svg className="moon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 14.5A8.5 8.5 0 019.5 4 8.5 8.5 0 1020 14.5z" /></svg>
          </button>
          <a className="c-btn ghost c-hide" href="/Muhammad_Bilal_CV.pdf" download>Resume</a>
          <a className="c-btn dark c-hide" href="#contact">Hire me</a>
          <button className="c-burger" aria-label={o ? "Close menu" : "Open menu"} aria-expanded={o} onClick={() => setO(!o)}><i /><i /></button>
        </div>
      </div>
      <div className="c-sheet">
        {L.map(([t, h]) => <a key={h} href={h} onClick={close}>{t}</a>)}
        <div><a className="c-btn ghost" href="/Muhammad_Bilal_CV.pdf" download onClick={close}>Resume</a><a className="c-btn dark" href="#contact" onClick={close}>Hire me</a></div>
      </div>
    </header>
  );
}
