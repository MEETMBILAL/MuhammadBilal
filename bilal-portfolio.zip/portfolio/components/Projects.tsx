// @ts-nocheck
"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";

const P = [
  { n: "EVT SaaS", tag: "Live product", d: "Estimates, quotes, invoices, analytics and client management for construction professionals, with AI-assisted estimation.", t: ["Django", "SQLite", "Auth", "AI"], c: "#b04ddb", bg: "#F6EBFC", a: "a1" },
  { n: "LandDesign", tag: "Dashboard", d: "A portfolio analytics dashboard tracking land projects across Alexandria, Fairfax, Loudoun County and Washington DC.", t: ["Charts", "Heatmaps", "Export"], c: "#4B9BE0", bg: "#EAF5FF", a: "a2" },
  { n: "After Concept", tag: "Agency platform", d: "The agency's Next.js site with AI features, built in TypeScript and Tailwind CSS from Figma designs.", t: ["Next.js", "TypeScript", "Tailwind"], c: "#00a3ba", bg: "#E4F7FA", a: "a3", u: "https://afterconcept.io" },
  { n: "BookShelf Online", tag: "E-commerce", d: "A fast, SEO-ready bookstore front end in HTML, CSS and JavaScript, deployed on Vercel.", t: ["HTML", "CSS", "SEO"], c: "#6a57e3", bg: "#ECE9FF", a: "a4", u: "https://bookshelfonline.vercel.app" },
];
const card = (d) => `<article class="cx" style="--bg:${d.bg};--dot:${d.c}"><div class="cx-art ${d.a}"></div><span class="cx-chip"><i></i>${d.tag}</span><div class="cx-body"><h3>${d.n}</h3><p>${d.d}</p><ul>${d.t.map((x) => `<li>${x}</li>`).join("")}</ul><a class="cx-link" href="${d.u || "#contact"}" ${d.u ? 'target="_blank" rel="noopener"' : ""}>${d.u ? "Visit site" : "Discuss a similar build"}</a></div></article>`;

export default function Projects() {
  const ref = useRef(null);
  useEffect(() => {
    const stage = ref.current, K = P.length, speed = { v: 1 }, st = { vel: 0 };
    let BASE = 0.045, slots = [], cw = 320, pitch = 344, total = 0, vw = 0, offset = 0, hovered = null, dragging = false;
    function build() {
      vw = stage.clientWidth; cw = Math.max(270, Math.min(360, vw * 0.3)); pitch = cw + 24;
      const need = Math.ceil(vw / pitch) + 2, count = K * Math.ceil(need / K);
      total = count * pitch; stage.innerHTML = ""; slots = []; hovered = null;
      for (let i = 0; i < count; i++) {
        const el = document.createElement("div"); el.className = "pc-slot"; el.style.width = cw + "px"; el.innerHTML = card(P[i % K]); stage.appendChild(el);
        const s = { el, card: el.firstChild, i, blur: 9, op: 0.5 };
        el.addEventListener("pointerenter", (e) => { if (e.pointerType === "mouse" && !dragging && hovered !== s) hover(s, true); });
        el.addEventListener("pointerleave", () => { if (hovered === s) hover(s, false); });
        slots.push(s);
      }
    }
    const upd = () => { const on = !(hovered || dragging); gsap.to(speed, { v: on ? 1 : 0, duration: on ? 1.1 : 0.6, ease: "power2.out", overwrite: true }); };
    function hover(s, on) { s.el.classList.toggle("hot", on); s.el.style.zIndex = on ? 5 : ""; gsap.to(s.card, { scale: on ? 1.06 : 1, duration: 0.5, ease: "power3.out", overwrite: true }); hovered = on ? s : null; upd(); }
    let sx = 0, lx = 0, lt = 0, v = 0, moved = 0, pid = null;
    const down = (e) => { if (e.pointerType === "mouse" && e.button !== 0) return; pid = e.pointerId; sx = lx = e.clientX; lt = performance.now(); v = 0; moved = 0; addEventListener("pointermove", move); addEventListener("pointerup", up); addEventListener("pointercancel", up); };
    function move(e) {
      if (e.pointerId !== pid) return;
      const dx = e.clientX - lx, now = performance.now(), dt = Math.max(1, now - lt); moved = Math.abs(e.clientX - sx);
      if (!dragging && moved > 4) { dragging = true; stage.classList.add("drag"); gsap.killTweensOf(st); st.vel = 0; if (hovered) hover(hovered, false); upd(); }
      if (dragging) { offset -= dx; v = v * 0.7 + (dx / dt) * 0.3; }
      lx = e.clientX; lt = now;
    }
    function up(e) {
      if (e.pointerId !== pid) return;
      removeEventListener("pointermove", move); removeEventListener("pointerup", up); removeEventListener("pointercancel", up);
      if (dragging) { dragging = false; stage.classList.remove("drag"); if (performance.now() - lt > 80) v = 0; st.vel = -Math.max(-3, Math.min(3, v)); gsap.to(st, { vel: 0, duration: 1.4, ease: "power3.out" }); upd(); }
      pid = null;
    }
    const block = (e) => { if (moved > 4) { e.stopPropagation(); e.preventDefault(); } };
    const tick = (time, dt) => {
      dt = Math.min(dt, 50);
      if (!dragging) offset += (speed.v * BASE + st.vel) * dt;
      offset = ((offset % total) + total) % total;
      const cx = vw / 2;
      for (const s of slots) {
        const x = ((((s.i * pitch - offset) % total) + total) % total) - pitch, dist = Math.abs(cx - (x + cw / 2)) / pitch;
        const tb = s === hovered ? 0 : Math.max(0, dist - 0.15) * 2.4, to = s === hovered ? 1 : Math.max(0.55, 1 - dist * 0.12);
        s.blur += (tb - s.blur) * 0.2; s.op += (to - s.op) * 0.2;
        s.el.style.transform = `translate3d(${x.toFixed(2)}px,0,0)`; s.el.style.filter = s.blur < 0.05 ? "none" : `blur(${s.blur.toFixed(2)}px)`; s.el.style.opacity = s.op.toFixed(3);
      }
    };
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) BASE = 0.012;
    build();
    let rt; const rs = () => { clearTimeout(rt); rt = setTimeout(build, 150); };
    stage.addEventListener("pointerdown", down); stage.addEventListener("click", block, true); stage.addEventListener("dragstart", (e) => e.preventDefault()); addEventListener("resize", rs);
    gsap.ticker.add(tick);
    return () => { gsap.ticker.remove(tick); gsap.killTweensOf(speed); gsap.killTweensOf(st); removeEventListener("resize", rs); removeEventListener("pointermove", move); removeEventListener("pointerup", up); stage.removeEventListener("pointerdown", down); stage.removeEventListener("click", block, true); };
  }, []);
  return (
    <section className="c-proj" id="work">
      <div className="c-wrap c-head">
        <p className="eyebrow">Selected work</p>
        <h2>Built for real users, shipped to production.</h2>
        <p>Four projects from my first six months: a live SaaS, a multi-city dashboard and two client sites. Hover a card to hold it still, or drag the row.</p>
      </div>
      <div className="pc-stage" ref={ref} aria-label="Projects" />
    </section>
  );
}
