// @ts-nocheck
"use client";
import { useEffect, useRef } from "react";

export default function Word() {
  const sec = useRef(null), cv = useRef(null);
  useEffect(() => {
    const st = sec.current, c = cv.current, ctx = c.getContext("2d");
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const cl = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
    const sm = (a, b, v) => { const t = cl((v - a) / (b - a)); return t * t * (3 - 2 * t); };
    const mk = (a) => () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    let COL = ["#14171f", "#4B9BE0", "#b04ddb", "#00a3ba"]; const DUR = 1500;
    let W = 0, H = 0, DPR = 1, tc, B = [], raf = 0, done = false, ready = false, want = false, started = false, t0 = 0, rt;
    const font = (s) => `900 ${s}px Inter,"Helvetica Neue",Arial,sans-serif`;
    function build() {
      const cs = getComputedStyle(st), v = (n, d) => cs.getPropertyValue(n).trim() || d;
      COL = [v("--ink", "#14171f"), v("--accent", "#4B9BE0"), v("--violet", "#b04ddb"), v("--cyan", "#00a3ba")];
      W = st.clientWidth; H = st.clientHeight; DPR = Math.min(devicePixelRatio || 1, 2);
      c.width = (W * DPR) | 0; c.height = (H * DPR) | 0;
      let fs = Math.min(W * 0.14, H * 0.22, 240);
      tc = document.createElement("canvas"); tc.width = c.width; tc.height = c.height;
      const t = tc.getContext("2d", { willReadFrequently: true }); t.scale(DPR, DPR);
      const setf = () => { t.font = font(fs); t.letterSpacing = "-0.02em"; t.textAlign = "center"; t.textBaseline = "middle"; };
      setf(); const mw = t.measureText("FULL STACK").width; if (mw > W * 0.88) { fs *= (W * 0.88) / mw; setf(); }
      const lh = fs * 0.98, cy = H * 0.46;
      t.fillText("FULL STACK", W / 2, cy - lh / 2); t.fillText("ENGINEER", W / 2, cy + lh / 2);
      const img = t.getImageData(0, 0, tc.width, tc.height).data, r = mk(7), step = Math.max(4, fs / 16), pts = [];
      for (let y = cy - lh - fs * 0.1; y < cy + lh + fs * 0.1; y += step) for (let x = W * 0.04; x < W * 0.96; x += step) {
        const jx = x + (r() - 0.5) * step * 0.45, jy = y + (r() - 0.5) * step * 0.45, ix = Math.floor(jx * DPR), iy = Math.floor(jy * DPR);
        if (ix >= 0 && iy >= 0 && ix < tc.width && iy < tc.height && img[(iy * tc.width + ix) * 4 + 3] > 128) pts.push([jx, jy]);
      }
      t.clearRect(0, 0, W, H);
      const g = t.createLinearGradient(W * 0.15, 0, W * 0.85, 0); g.addColorStop(0, COL[1]); g.addColorStop(0.5, COL[2]); g.addColorStop(1, COL[3]);
      t.fillStyle = g; t.fillText("FULL STACK", W / 2, cy - lh / 2); t.fillText("ENGINEER", W / 2, cy + lh / 2);
      const shape = () => { const n = 5 + Math.floor(r() * 3), a = [], o = r() * 6.28; for (let i = 0; i < n; i++) { const an = o + (i / n) * 6.283 + (r() - 0.5) * 0.6, rd = 0.55 + r() * 0.45; a.push(Math.cos(an) * rd, Math.sin(an) * rd); } return a; };
      const pick = () => { const v = r(); return v < 0.4 ? 0 : v < 0.68 ? 1 : v < 0.86 ? 2 : 3; };
      B = [[], [], [], []];
      for (const [tx, ty] of pts) {
        const sx = W * (r() * 1.1 - 0.05), sy = H * (r() * 0.95 - 0.1), dist = Math.hypot((sx - W / 2) / W, (sy - H / 2) / H);
        B[pick()].push({ sx, sy, tx, ty, sz: step * (0.8 + r() * 1.5), tz: step * 1.9, sh: shape(), r0: r() * 6.28, sp: (r() - 0.5) * 28, ph: r() * 6.28, fl: 4 + r() * 14, t0: 0.04 + dist * 0.08 + r() * 0.2, k: 5 + r() * 4, dx: (r() - 0.5) * W * 0.12, dy: H * (0.12 + r() * 0.3), c0: 0.36 + (tx / W) * 0.14 + r() * 0.06, cd: 0.2 + r() * 0.05 });
      }
    }
    function draw(p) {
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0); ctx.clearRect(0, 0, W, H);
      const s = sm(0.8, 0.97, p);
      if (s < 1) for (let b = 0; b < 4; b++) {
        ctx.globalAlpha = 1 - s; ctx.fillStyle = COL[b]; ctx.beginPath();
        for (const q of B[b]) {
          const u = p - q.t0; if (u <= 0) continue;
          const f = 1 - Math.exp(-u * q.k);
          let x = q.sx + q.dx * f + Math.sin(u * 16 + q.ph) * q.fl * f, y = q.sy + q.dy * f, rot = q.r0 + q.sp * Math.min(u, 0.35), sz = q.sz * Math.min(1, u / 0.04);
          const w = cl((p - q.c0) / q.cd), e = w < 0.5 ? 4 * w * w * w : 1 - Math.pow(-2 * w + 2, 3) / 2;
          x += (q.tx - x) * e; y += (q.ty - y) * e; rot *= 1 - e; sz += (q.tz - sz) * e;
          if (sz < 0.3) continue;
          const co = Math.cos(rot), si = Math.sin(rot), a = q.sh;
          for (let i = 0; i < a.length; i += 2) { const vx = a[i] * sz, vy = a[i + 1] * sz, px = x + vx * co - vy * si, py = y + vx * si + vy * co; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
          ctx.closePath();
        }
        ctx.fill();
      }
      if (s > 0) { ctx.globalAlpha = s; ctx.drawImage(tc, 0, 0, W, H); }
      ctx.globalAlpha = 1;
    }
    const finish = () => { done = true; draw(1); st.classList.add("done"); };
    function loop(now) { const p = cl((now - t0) / DUR); draw(p); if (p < 1) raf = requestAnimationFrame(loop); else finish(); }
    function go() { if (started || !ready || !want) return; started = true; if (reduce) return finish(); t0 = performance.now(); raf = requestAnimationFrame(loop); }
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { want = true; go(); io.disconnect(); } }, { threshold: 0.6 });
    io.observe(st);
    const init = () => { build(); ready = true; go(); };
    Promise.race([document.fonts.load("900 100px Inter"), new Promise((r) => setTimeout(r, 1500))]).then(init, init);
    const ro = new ResizeObserver(() => { clearTimeout(rt); rt = setTimeout(() => { if (!ready || (Math.abs(st.clientWidth - W) < 2 && Math.abs(st.clientHeight - H) < 60)) return; cancelAnimationFrame(raf); build(); if (done) draw(1); else if (started) { started = false; go(); } }, 150); });
    ro.observe(st);
    const mo = new MutationObserver(() => { if (!ready) return; build(); if (done) draw(1); });
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    return () => { cancelAnimationFrame(raf); io.disconnect(); ro.disconnect(); mo.disconnect(); clearTimeout(rt); };
  }, []);
  return (
    <section ref={sec} className="w-sec" aria-label="Full Stack Engineer">
      <h2 className="sr">Full Stack Engineer</h2>
      <canvas ref={cv} aria-hidden="true" />
      <p className="w-cap">React and Next.js in front, Python and Django behind.</p>
    </section>
  );
}
