// @ts-nocheck
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);
export default function init(root) {
  const __c = []; let __dead = false, __raf = 0;
  const __tk = (f) => { gsap.ticker.add(f); __c.push(() => gsap.ticker.remove(f)); };
  const __ae = (...a) => { window.addEventListener(...a); __c.push(() => window.removeEventListener(...a)); };
  const RO = function (cb) { const o = new ResizeObserver(cb); __c.push(() => o.disconnect()); return o; };
  const ctx = gsap.context(() => {

const SK=[
{n:"React",c:"Frontend library",d:"Component-driven interfaces built with hooks, composition and predictable state.",s:'<svg viewBox="-12 -12 24 24"><g fill="none" stroke="#3FC6EE" stroke-width="1.1"><ellipse rx="10" ry="4"/><ellipse rx="10" ry="4" transform="rotate(60)"/><ellipse rx="10" ry="4" transform="rotate(120)"/></g><circle r="1.9" fill="#3FC6EE"/></svg>'},
{n:"JavaScript",c:"Programming language",d:"The language behind every interaction, from DOM logic to async data flows.",s:'<svg viewBox="0 0 24 24"><rect width="24" height="24" rx="3" fill="#F7DF1E"/><text x="21.5" y="21" text-anchor="end" font-family="Arial,sans-serif" font-weight="800" font-size="12" fill="#222">JS</text></svg>'},
{n:"Next.js",c:"Full-stack framework",d:"Full-stack React with routing, server rendering and optimised delivery.",s:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#111"/><path d="M8.3 7.5v9M8.3 7.5l7.6 9.6M15.8 7.5v5" stroke="#fff" stroke-width="1.5" fill="none"/></svg>'},
{n:"TypeScript",c:"Typed language",d:"Static types that make large codebases safer and easier to refactor.",s:'<svg viewBox="0 0 24 24"><rect width="24" height="24" rx="3" fill="#3178C6"/><text x="21.5" y="21" text-anchor="end" font-family="Arial,sans-serif" font-weight="800" font-size="12" fill="#fff">TS</text></svg>'},
{n:"Tailwind CSS",c:"Styling system",d:"Utility-first styling for consistent, responsive design systems.",s:'<svg viewBox="0 0 24 24"><path fill="#38BDF8" d="M12 6c-2.67 0-4.33 1.33-5 4 1-1.33 2.17-1.83 3.5-1.5.76.19 1.31.74 1.91 1.35.98 1 2.09 2.15 4.59 2.15 2.67 0 4.33-1.33 5-4-1 1.33-2.17 1.83-3.5 1.5-.76-.19-1.3-.74-1.91-1.35C15.61 7.15 14.5 6 12 6zm-5 6c-2.67 0-4.33 1.33-5 4 1-1.33 2.17-1.83 3.5-1.5.76.19 1.3.74 1.91 1.35C8.39 16.85 9.5 18 12 18c2.67 0 4.33-1.33 5-4-1 1.33-2.17 1.83-3.5 1.5-.76-.19-1.3-.74-1.91-1.35C10.61 13.15 9.5 12 7 12z"/></svg>'},
{n:"Python",c:"Programming language",d:"Clean scripting and backend logic, from automation to data work.",s:'<svg viewBox="0 0 24 24"><path fill="#3776AB" d="M11.9 2C7.5 2 7.8 4 7.8 4v2h4.2v.6H5.9S3 6.3 3 10.9s2.5 4.4 2.5 4.4H7v-2.1s-.1-2.5 2.4-2.5h4.2s2.3 0 2.3-2.3V4.4S16.3 2 11.9 2zM9.6 3.4a.8.8 0 110 1.5.8.8 0 010-1.5z"/><path fill="#FFD43B" d="M12.1 22c4.4 0 4.1-2 4.1-2v-2h-4.2v-.6h6.1S21 17.7 21 13.1s-2.5-4.4-2.5-4.4H17v2.1s.1 2.5-2.4 2.5h-4.2s-2.3 0-2.3 2.3v3.4S7.7 22 12.1 22zm2.3-1.4a.8.8 0 110-1.5.8.8 0 010 1.5z"/></svg>'},
{n:"Django",c:"Backend framework",d:"A batteries-included backend framework for secure, maintainable web apps.",s:'<svg viewBox="0 0 24 24"><rect width="24" height="24" rx="4" fill="#0C4B33"/><text x="12" y="17.5" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="14" fill="#fff">dj</text></svg>'},
{n:"Git",c:"Version control",d:"Branching, review and clear history that keep collaboration orderly.",s:'<svg viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="17" height="17" rx="2.5" transform="rotate(45 12 12)" fill="#F05032"/><path d="M12 8v8M12 12l3.6-2.2" stroke="#fff" stroke-width="1.5" fill="none"/><g fill="#fff"><circle cx="12" cy="8" r="1.8"/><circle cx="12" cy="16" r="1.8"/><circle cx="15.6" cy="9.8" r="1.8"/></g></svg>'},
{n:'HTML5',c:'Markup language',d:'Semantic, accessible structure that every interface is built on.',s:'<svg viewBox="0 0 24 24"><path fill="#E44D26" d="M3 2l1.6 18L12 22l7.4-2L21 2z"/><text x="12" y="16" text-anchor="middle" font-family="Arial" font-weight="800" font-size="10" fill="#fff">5</text></svg>'},
{n:'CSS3',c:'Styling language',d:'Layouts, responsive design and detail work without fighting the cascade.',s:'<svg viewBox="0 0 24 24"><path fill="#1572B6" d="M3 2l1.6 18L12 22l7.4-2L21 2z"/><text x="12" y="16" text-anchor="middle" font-family="Arial" font-weight="800" font-size="10" fill="#fff">3</text></svg>'},
{n:'Bootstrap',c:'CSS framework',d:'Quick, consistent grids and components for client sites.',s:'<svg viewBox="0 0 24 24"><rect width="24" height="24" rx="4" fill="#7952B3"/><text x="12" y="17" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="15" fill="#fff">B</text></svg>'},
{n:'Node.js',c:'JavaScript runtime',d:'JavaScript on the server for tooling, scripts and small services.',s:'<svg viewBox="0 0 24 24"><path fill="#3C873A" d="M12 1.5l9 5.2v10.6l-9 5.2-9-5.2V6.7z"/><text x="12" y="15.5" text-anchor="middle" font-family="Arial" font-weight="800" font-size="9" fill="#fff">JS</text></svg>'},
{n:'REST APIs',c:'API design',d:'Clean endpoints and integrations that connect frontend and backend.',s:'<svg viewBox="0 0 24 24"><rect width="24" height="24" rx="4" fill="#6A57E3"/><text x="12" y="15" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="9" fill="#fff">API</text></svg>'},
{n:'SQLite',c:'Database',d:'Data models and storage behind Django projects.',s:'<svg viewBox="0 0 24 24"><g fill="#0F80CC"><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 8.5v9.5c0 1.7 3.6 3 8 3s8-1.3 8-3V8.5c0 1.7-3.6 3-8 3s-8-1.3-8-3z"/></g></svg>'},
{n:'GitHub',c:'Code hosting',d:'Pull requests, reviews and shared repositories.',s:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#14171F"/><path fill="#fff" d="M12 4.5a7.5 7.5 0 00-2.4 14.6c.4.1.5-.2.5-.4v-1.4c-2.100.5-2.500-1-2.500-1-.3-.9-.8-1.100-.8-1.100-.7-.5.1-.5.1-.5.8.1 1.200.8 1.200.8.7 1.200 1.800.8 2.300.6.1-.5.3-.8.5-1-1.700-.2-3.400-.8-3.400-3.700 0-.8.3-1.500.8-2-.1-.2-.3-1 .1-2 0 0 .6-.2 2.100.8a7.200 7.200 0 013.800 0c1.400-1 2.100-.8 2.100-.8.400 1 .2 1.800.1 2 .5.500.8 1.200.8 2 0 2.900-1.700 3.500-3.400 3.700.3.200.5.700.5 1.400v2.100c0 .2.1.5.5.4A7.500 7.500 0 0012 4.500z"/></svg>'},
{n:'Figma',c:'Design tool',d:'Layouts and prototypes that turn into code without surprises.',s:'<svg viewBox="0 0 24 24"><path fill="#F24E1E" d="M9 2h3v6H9a3 3 0 010-6z"/><path fill="#FF7262" d="M12 2h3a3 3 0 010 6h-3z"/><path fill="#A259FF" d="M9 8h3v6H9a3 3 0 010-6z"/><circle fill="#1ABCFE" cx="15" cy="11" r="3"/><path fill="#0ACF83" d="M9 14h3v3a3 3 0 11-3-3z"/></svg>'}
];
const NS=SK.length,N=16,$=s=>root.querySelector(s),cl=(v,a,b)=>Math.max(a,Math.min(b,v));
const stage=$('.stage'),scene=$('.scene'),ring=$('.ring'),prev=$('#prev'),next=$('#next'),fill=$('.prog i');
const RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
const S={pos:0,idx:0,scr:0,t:RM?1:0};
ring.innerHTML=Array.from({length:N},(_,i)=>{const k=SK[i%NS];return `<div class="card" role="group" ${i<NS?`aria-label="${k.n}, ${i+1} of ${NS}"`:'aria-hidden="true"'}><div class="lg">${k.s}</div><div class="nm">${k.n}</div><div class="ct">${k.c}</div><i class="ln"></i></div>`}).join('');
const cards=[...ring.children],pls=[...root.querySelectorAll('.pl')];
let W,H,SP,R,STEP,gs,CP,RP,cy=0,shown=-1,hold=0;
function layout(){
  const sw=scene.clientWidth,sh=scene.clientHeight,hd=$('.hd'),inf=$('.info');
  const top=hd.offsetTop+hd.offsetHeight+6,bot=inf.offsetTop-6,fh=Math.max(160,bot-top);
  cy=(top+bot)/2-sh/2;
  const w=sw<640?sw*.46:sw<1024?sw*.26:cl(sw*.17,170,260);
  W=Math.min(w,fh*.84/1.22);H=W*1.22;SP=W*1.1;STEP=sw<640?.5:sw<1024?.44:Math.PI*2/N;R=SP/STEP;
  gs=Math.min(sw*.88/4*.92/W,sh*.86/4*.92/H);CP=W*gs*1.14;RP=H*gs*1.1;
  stage.style.setProperty('--cw',W+'px');stage.style.setProperty('--ch',H+'px');stage.style.setProperty('--cy',cy+'px');
  scene.style.perspective=W*6+'px';scene.style.perspectiveOrigin=`50% ${sh/2+cy}px`;
}
function setActive(k){
  if(k===shown)return;const first=shown<0;shown=k;const s=SK[k];
  $('#cat').textContent=s.c;$('#ttl').textContent=s.n;$('#dsc').textContent=s.d;
  $('#cur').textContent=String(k+1).padStart(2,'0');
  if(!first&&!RM)gsap.fromTo(root.querySelectorAll('.swap'),{autoAlpha:0,y:10},{autoAlpha:1,y:0,duration:.4,overwrite:'auto'});
}
function render(){
  const t=S.t,e=t*t*(3-2*t),P=S.pos+S.scr;
  for(let i=0;i<N;i++){
    const r=i>>2,c=i&3;
    let q=cl((t-(r+c)*.07)/.58,0,1);q=q*q*(3-2*q);           /* corner-first stagger */
    let d=i-P;d-=N*Math.round(d/N);                            /* wrap: endless loop */
    const ad=Math.abs(d),dd=cl(d,-3.4,3.4),ang=dd*STEP,act=Math.max(0,1-ad),m=Math.min(ad,3);
    const xg=(c-1.5)*CP,yg=(r-1.5)*RP;
    const x3=R*Math.sin(ang)+(d-dd)*SP*.4,y3=cy-act*14+m*6,z3=R*Math.cos(ang)-R+act*70;
    const x=xg+(x3-xg)*q,y=yg+(y3-yg)*q,z=q*z3+Math.sin(q*Math.PI)*W*.9;
    const s=gs+q*(1+.1*act-.035*m-gs),o3=Math.max(0,1-ad*.2),el=cards[i];
    el.style.transform=`translate3d(${x.toFixed(2)}px,${y.toFixed(2)}px,${z.toFixed(2)}px) rotateY(${(ang*q*57.2958).toFixed(2)}deg) scale(${s.toFixed(3)})`;
    el.style.opacity=(1-(1-o3)*q).toFixed(3);
    el.style.setProperty('--a',(act*q).toFixed(3));el.style.setProperty('--q',q.toFixed(3));
  }
  scene.style.setProperty('--e',e.toFixed(3));stage.style.setProperty('--e2',e.toFixed(3));
  pls.forEach(p=>p.style.transform=`translate3d(${(Math.sin(P*.3)*p.dataset.k*3).toFixed(1)}px,0,0)`);
  const k=(((Math.round(P)%N)+N)%N)%NS,f=((P%NS)+NS)%NS;
  fill.style.transform=`scaleX(${cl((f+1)/NS,0,1).toFixed(3)})`;setActive(k);
}
const pause=ms=>hold=performance.now()+ms;
function go(x,dur=.9){S.idx=x;gsap.killTweensOf(S,'pos');gsap.to(S,{pos:x,duration:RM?0:dur,ease:'power3.out',onUpdate:render})}
const step=(dir,dur)=>go(Math.round(S.idx+S.scr)+dir-S.scr,dur);

/* drag / swipe (infinite in both directions) */
let drag=null,didDrag=false,settle;
scene.addEventListener('pointerdown',e=>{
  if(S.t<.97||(e.pointerType==='mouse'&&e.button!==0))return;
  didDrag=false;gsap.killTweensOf(S,'pos');hold=1e15;
  drag={id:e.pointerId,x:e.clientX,p:S.pos,lx:e.clientX,lt:performance.now(),v:0,moved:false};
});
scene.addEventListener('pointermove',e=>{
  if(!drag||e.pointerId!==drag.id)return;
  const dx=e.clientX-drag.x;
  if(!drag.moved){if(Math.abs(dx)<5)return;drag.moved=didDrag=true;scene.setPointerCapture(e.pointerId);scene.classList.add('grab')}
  const n=performance.now(),dt=Math.max(1,n-drag.lt);
  drag.v=drag.v*.6+((e.clientX-drag.lx)/dt)*.4;drag.lx=e.clientX;drag.lt=n;
  S.pos=drag.p-dx/SP;render();
});
function endDrag(){
  if(!drag)return;const m=drag.moved,v=drag.v;drag=null;scene.classList.remove('grab');pause(2500);
  go(m?Math.round(S.pos+S.scr-cl(v/SP*260,-2.5,2.5))-S.scr:S.idx,.8);
}
['pointerup','pointercancel','lostpointercapture'].forEach(ev=>scene.addEventListener(ev,endDrag));
scene.addEventListener('dragstart',e=>e.preventDefault());
ring.addEventListener('click',e=>{
  const c=e.target.closest('.card');if(!c||didDrag||S.t<.97)return;
  const P=S.pos+S.scr;let d=cards.indexOf(c)-P;d-=N*Math.round(d/N);pause(3000);go(Math.round(P+d)-S.scr);
});
prev.onclick=()=>{pause(3000);step(-1)};next.onclick=()=>{pause(3000);step(1)};

/* horizontal trackpad wheel; vertical wheel stays page scroll (it drives the wheel via ScrollTrigger) */
stage.addEventListener('wheel',e=>{
  if(S.t<.97||Math.abs(e.deltaX)<=Math.abs(e.deltaY))return;
  e.preventDefault();gsap.killTweensOf(S,'pos');pause(2500);S.pos+=e.deltaX/SP*.6;S.idx=S.pos;render();
  clearTimeout(settle);settle=setTimeout(()=>go(Math.round(S.pos+S.scr)-S.scr,.6),160);
},{passive:false});
__ae('keydown',e=>{
  if(e.key!=='ArrowRight'&&e.key!=='ArrowLeft')return;
  const r=stage.getBoundingClientRect();if(r.top>innerHeight*.5||r.bottom<innerHeight*.5)return;
  e.preventDefault();pause(3000);step(e.key==='ArrowRight'?1:-1);
});

/* auto-play: one card every ~1.5s, right to left */
(function auto(){if(__dead)return;setTimeout(()=>{
  const r=stage.getBoundingClientRect();
  if(!RM&&!document.hidden&&!drag&&performance.now()>hold&&S.t>.97&&r.top<innerHeight*.5&&r.bottom>innerHeight*.5)step(1,1);
  auto();},1500)})();

layout();render();
__ae('resize',()=>{layout();render()});
document.fonts&&document.fonts.ready.then(()=>{layout();render()});

if(!RM){
  gsap.registerPlugin(ScrollTrigger);
  const tl=gsap.timeline({scrollTrigger:{trigger:stage,start:'top top',end:'+=700%',pin:true,scrub:.7,anticipatePin:1,invalidateOnRefresh:true}});
  tl.to(S,{t:1,duration:1,ease:'none',onUpdate:render},0).to(S,{scr:16,duration:6,ease:'none',onUpdate:render},1);
  root.querySelectorAll('[data-at]').forEach(el=>tl.fromTo(el,{autoAlpha:0,y:26},{autoAlpha:1,y:0,duration:.22,ease:'power2.out'},+el.dataset.at));
}

  });
  return () => { __dead = true; cancelAnimationFrame(__raf); __c.forEach((f) => f()); ctx.revert(); };
}
