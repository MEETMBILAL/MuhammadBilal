import Nav from "@/components/Nav";
import { Hero, Contact, Footer } from "@/components/Sections";
import Projects from "@/components/Projects";
import Skills from "@/components/Skills";
import Services from "@/components/Services";
import Journey from "@/components/Journey";
import Word from "@/components/Word";

export default function Page() {
  return (
    <main id="top">
      <Nav />
      <Hero />
      <Projects />
      <Skills />
      <Services />
      <Journey />
      <Word />
      <Contact />
      <Footer />
    </main>
  );
}
