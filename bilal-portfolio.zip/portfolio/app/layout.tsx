import "./globals.css";
export const metadata = {
  title: "Muhammad Bilal — Full Stack Developer",
  description: "Full Stack Developer building React/Next.js interfaces and Python/Django backends. Open to remote work worldwide.",
};
const theme = `try{var t=localStorage.getItem('theme')||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light');document.documentElement.dataset.theme=t}catch(e){document.documentElement.dataset.theme='light'}`;
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: theme }} />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&family=Source+Serif+4:wght@400;500;600&family=DM+Mono:wght@400;500&family=Mrs+Saint+Delafield&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  );
}
